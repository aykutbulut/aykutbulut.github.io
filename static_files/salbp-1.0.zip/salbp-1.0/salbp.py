#salbp.py

'''
Brief description:
Contains Salb class which creates/solves Simple Assembly Line Balancing
Problem, type 2

Detailed description:
Classes contained:
Salb (LpProblem):
    attributes:
            pred:    predecessor dictionary, keys are tasks, values are sets
                     gives set of predecessors of the provided key
                     type: dictionary of sets
            taskTime:
                     dictonary that gives task times, keys are tasks
                     type: dictionary
            taskList:
                     keeps list of tasks
                     type: list
            precedenceGraph:
                     Dot graph instance that keeps the precedence network of
                     the problem
                     type: Dot
            modelBuild:
                     True if the model is built (variables, constrains etc.)
                     False otherwise
                     type: bool
            precedenceGraphBuild
                     True if precedenceGraph is created from precedence data
                     provided, False otherwise
                     type: bool
    methods:
        __init__(self, name, sense = LpMinimize):
                     initializes class instance, name is problem name input
        gen_input(self, nrTask, nrWorkstation, meanTaskTime = 100,
                  minRatio = 10, maxRatio = 2, pRatio = 0.8, pDistance = 3,
                  seedInput = 0):
                     generates random input from many parameters, generating
                     random input for an optimization problem is not a good
                     idea, and the method is not well-tested, use at your
                     own risk!
        solve(self, meanBanchLen):
                       draws tree by calling either draw_r() or draw_nr()
                       method
        read_input(self, filepath):
                       reads SALBP type 2 test problem input files
                       downloaded from http://alb.mansci.de/
                       you can also get them from
                       http://coral.ie.lehigh.edu/~aykut
        assign_predecessor(self,task,predecessor):
                       adds predecessor to task's predecessor set
        assign_task_time(self,task,time):
                       assigns task time
        assign_number_of_workstations(nrWorkstation):
                       assigns number of workstations
        _build_problem(self):
                       builds problem from provided data
        save_precedence_graph(self,filename='precedence_graph',format='png'):
                       saves precedence graph
                       filename and format are optional
        _build_dot_graph(self):
                       builds precedenceGraph graph from provided data 
        salbp_solve(self):
                       solves problem
        writeSALBP(self, filepath):
                       writes problem in LP format to the provided file path
        get_ordering_strength(self):
                       gets order strength measure of the precedence network
        get_flexibility_ratio(self):
                       gets flexibility ratio measure of the precedence
                       network
        get_west_ratio(self):
                       gets west ratio measure of the precedence network
'''

__version__    = '1.0.0'
__author__     = 'Aykut Bulut, ayb211.at.lehigh.$dot$.edu'
__license__    = 'BSD'
__maintainer__ = 'Aykut Bulut'
__email__      = 'ayb211.at.lehigh.$dot$.edu'
__title__      = 'Simple Assembly Line Balancing Problem'

from pulp import LpProblem, LpVariable, LpMinimize
from pulp import LpBinary, LpContinuous, lpSum, COIN
from pydot import Dot, Node, Edge
import random

#TODO:
# add methods to calculate measures from precedence graph

class Salbp(LpProblem):
    def __init__(self, name = 'SALBP'):
        '''
        initializes class instance, name is problem name input
        '''
        LpProblem.__init__(self, name, sense = LpMinimize)
        self.pred = {}
        self.taskTime = {}
        self.taskList = []
        self.precedenceGraph = Dot(splines = 'true', K = 2)
        self.modelBuild = False
        self.precedenceGraphBuild = False

    def gen_input(self, nrTask, nrWorkstation, meanTaskTime = 100, minRatio = 10,
                  maxRatio = 2, pRatio = 0.8, pDistance = 3, seedInput = 0):
        '''
        generates random input from many parameters, generating
        random input for
        an optimization problem is not a good idea, and the
        method is not well-tested, use at your own risk!
        generates precedence graph
        generates task times
        '''
        random.seed(seedInput)
        self.assign_number_of_workstations(nrWorkstation)
        for i in range(1,nrTask+1):
            self.assign_task_time(i,
                meanTaskTime+random.randint(meanTaskTime/minRatio,meanTaskTime*maxRatio))
        for i in range(1,nrTask+1):
            for j in range(max(1,i-pDistance),i):
                if random.random() < pRatio:
                    self.assign_predecessor(i,j)

    def read_input(self, filepath):
        '''
        reads SALBP type 2 test problem input files
        downloaded from http://alb.mansci.de/
        you can also get them from
        http://coral.ie.lehigh.edu/~aykut
        '''
        f = open(filepath,'r')
        nrTask = f.readline()
        nrTask = nrTask.strip()
        nrTask = int(nrTask)
        for i in range(nrTask):
            self.assign_task_time(i+1, int(f.readline().strip()))
        for line in f:
            line = line.strip()
            i,comma,j = line.partition(',')
            i, j = int(i), int(j)
            if i==-1 or j==-1:
                break
            self.assign_predecessor(j, i)

    def assign_predecessor(self, task, predecessor):
        '''
        adds predecessor to task's predecessor set
        '''
        if not isinstance(task, str):
            task = str(task)
        if not isinstance(predecessor, str):
            predecessor = str(predecessor)
        self.precedenceGraphBuild = False
        self.modelBuild = False
        if task not in self.taskList:
            self.taskList.append(task)
        if predecessor is None:
            self.pred[task] = set([])
            return
        if task in self.pred:
            self.pred[task].add(predecessor)
        else:
            self.pred[task] = set([])
            self.pred[task].add(predecessor)

    def assign_task_time(self, task, time):
        '''
        assigns task time
        '''
        if not isinstance(task, str):
            task = str(task)
        self.modelBuild = False
        self.taskTime[task] = time
        if task not in self.taskList:
            self.taskList.append(task)

    def assign_number_of_workstations(self, nrWorkstation):
        '''
        assigns number of workstations
        '''
        self.modelBuild = False
        self.nrWorkstation = nrWorkstation
        self.workstationList = list(str(k) for k in range(1,nrWorkstation+1))

    def _build_problem(self):
        '''
        builds the problem from provided data,
        i.e. adds constraints, defines obj func. etc.
        '''
        if self.modelBuild:
            return
        self.modelBuild = True
        x = {}
        for i in self.taskList:
            x[i] = {}
            for k in self.workstationList:
                x[i][k] = LpVariable('x_'+i+','+k, 0, 1, LpBinary)
        t = LpVariable('T', None, None, LpContinuous)
        # add obj function 
        self.__iadd__(t)
        #add task assignment constraint
        for i in self.taskList:
            taskAssignment = lpSum(x[i][k] for k in self.workstationList)
            self.__iadd__(taskAssignment==1)
        #add cycle time constraints
        for k in self.workstationList:
            cycleTimeC = lpSum(self.taskTime[i]*x[i][k] for i in self.taskList)
            self.__iadd__(t>=cycleTimeC)
        #add precedence constraints
        for i in self.taskList:
            if i in self.pred:
                for h in self.pred[i]:
                    for k in self.workstationList:
                        precedenceC = lpSum(x[h][str(j)] for j in range(1,int(k)+1))
                        precedenceC = precedenceC - x[i][k] 
                        self.__iadd__(precedenceC>=0)

    def save_precedence_graph(self, filename = 'precedence_graph', format = 'png'):
        '''
        saves precedence graph
        filename and format are optional
        '''
        if not self.precedenceGraphBuild:
            self._build_dot_graph()
        self.precedenceGraph.write(filename, self.precedenceGraph.get_layout(), format)

    def _build_dot_graph(self):
        self.precedenceGraphBuild = True
        '''
        builds Dot graph from self.pred
        changes self.precedenceGraph and self.precedenceGraphBuild
        '''
        for i in self.taskList:
            self.precedenceGraph.add_node(Node(i))
        for i in self.taskList:
            if i in self.pred:
                for j in self.pred[i]:
                    self.precedenceGraph.add_edge(Edge(j,i))
    
    def salbp_solve(self):
        '''
        builds (using _build_problem())and solves problem 
        '''
        if not self.modelBuild:
            self._build_problem()
        self.solve(COIN(msg=1,maxSeconds=3600.0))

    def writeSALBP(self, filepath):
        '''
        writes SALBP in LP format
        '''
        if not self.modelBuild:
            self._build_problem()
        self.writeLP(filepath)

    def get_ordering_strength(self):
        '''
        gets ordering strength
        ordering strength, measure defined by Mastor (1970)
        Number of precedence relations divided by the total possible number
        of precedence relations in P
        '''
        nrPredRelations = 0
        for t in self.taskList:
            if t in self.pred:
                nrPredRelations += len(self.pred[t])
        n = len(self.taskList)
        nrPosPredRelations = n*(n-1)/2
        return float(nrPredRelations) / float(nrPosPredRelations)  

    def get_flexibility_ratio(self):
        '''
        gets flexibility ratio
        flexibility ratio defined by Dar-El (1973)
        The number of zero entries in the precedence matrix of P divided by
        the number of entries in that matrix
        Higher f. ratio indicates less precedence constraints and greater
        flexibility in generating multiple feasible solutions
        (Rubinovitz et al., 1995)
        1.0 - ordering strength
        '''
        return 1.0 - self.get_ordering_strength()

    def get_west_ratio(self):
        '''
        gets west ratio
        west ratio defined by Dar-El (1973)
        number of tasks per station
        it is not fixed when we are solving type 1
        '''
        return float(len(self.taskList))/float(self.nrWorkstation)
