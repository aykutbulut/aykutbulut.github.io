var searchData=
[
  ['_5f_5finit_5f_5f',['__init__',['../classsalbp_1_1Salbp.html#aedb025164cdf47b9145031f26ef26d99',1,'salbp::Salbp']]]
];
