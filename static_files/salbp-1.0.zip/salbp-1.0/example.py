from salbp import Salbp

if __name__ == '__main__':
    p = Salbp()
    p.read_input('./test_problems/MUKHERJE.IN2')
    p.assign_number_of_workstations(10)
    #p.save_precedence_graph(filename = 'precedence_graph.png', format = 'png')
    #p.writeSALBP('salbp.lp')
    p.salbp_solve()